const config = {
    DB_Host: "localhost",
    DB_Port: "3306",
    DB_Username: "root",
    DB_Password: "",
    DB_Name: "registrations_db"
}
module.exports = config;