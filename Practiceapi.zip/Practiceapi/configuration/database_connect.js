const config = require("./config");
const mysql = require("mysql");
const util = require("util");
// console.log("jjnjnj");
const connect = mysql.createConnection({
      host:config.DB_Host,
      user:config.DB_Username,
      pass:config.DB_Password,
      database:config.DB_Name,
})
connect.connect(function(err){
       if(err) {
        console.log("error in result");
       }
       else{
        console.log("Database connected successfully");
       }
}) 
const query = util.promisify(connect.query).bind(connect)
module.exports = query;

