const express = require('express');
const app = express();
const cors = require("cors");
const port = 9249;
const config = require('./configuration/config');

// Middleware for parsing request bodies
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// CORS middleware
app.use(cors());

// Routes
app.use(require('./Routes/routes'));

app.listen(port, () => {
    console.log('Server is running on http://' + config.DB_Host + ':' + port);
});
