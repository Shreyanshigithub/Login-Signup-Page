const emailValidator = require("email-validator");
const jwt = require('jsonwebtoken')
const mysqlcon =require('../configuration/database_connect')
var md5 = require('md5');


module.exports.signup = async (req,res)=>{
    
    try {
        let { email, password } = req.body
        
        let details = {
            
            email,
            password: md5(password),
    
        }
        console.log(details);
   
        if (!email || !password) {
            return res.json(400, {
                message: `Please provide all fields`
            });
        }

        let sql = "INSERT INTO login SET ?";
        let result = await mysqlcon(sql, [details]);
    

        if (result) {
            return res.status(200).json({
                message:`SIGNUP SUCCESSFULLY`,
                data: details

            });
            
        }
    } catch (err) {
        console.log(err)
        return res.json(500, {
            message: `Error occured while signing up`,

        });
    }
}

module.exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;
        console.log(req.body);
        let details1 = {
            email,
            password,

        }

        if (details1.email && details1.password) {
            if (emailValidator.validate(email)) {
                const sqlquery = "SELECT * FROM  login WHERE email = ? AND password = ?";
                const data = await mysqlcon(sqlquery, [email, md5(password)]);
                if (Object.values(data).length > 0) {
                  
                    const sql= "SELECT id FROM  login WHERE email = ?";
                    const user_id = await mysqlcon(sql, [email]);
                   
                     let token= jwt.sign({user_id},"loginformtoken",{"expiresIn":"1h"})
                     return res.status(200).json({
                        message:` Login SUCCESSFULLY`,
                        data: details1,
                        token:token
                    });

                } else {
                    return res.status(401).json({
                        "status": "false",
                        "message": "credentials mismatched"
                    })
                }
            }
            else {
                return res.status(201).json({
                    "status": "false",
                    "message": "Invalid Email"
                })
            }
        } else {
            return res.status(400).json({
                "status": "false",
                "message": "Data not found"
            })
        }
    } catch (err) {
        console.log(err);
        return res.status(404).json({
            message: err,
        });
    }

}
