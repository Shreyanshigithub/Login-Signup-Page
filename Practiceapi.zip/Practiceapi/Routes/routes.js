const express = require("express");
const router = express.Router();
const userController = require("../login_controller/user");

router.post("/sign_up", userController.signup);
router.post("/login_form", userController.login);

module.exports = router;
